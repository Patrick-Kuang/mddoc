@(手稿)
# 36-year-old woman in her 28 weeks prenancy with anemia, thrombocytopenia and leukocytosis

![A. bone marrow biopsy showed 2~3+ with malignant cells B. Histochemical stain of the malignant cells](./marrow.jpg)

A 36-year-old woman presented to our department from emergency service for vomiting diarrhea and fatigue for about 3 weeks. She also complained weakness of her left body for 3 days. Blood routine showed severe anmemia (hemobglobin 57g/L), throbocytopenia (35×109/L) and leukocytosis (22.0×109/L). Myelocyte,metamyelocyte and nucleated RBC were detected on blood smear. Bone marrow aspiration was dry tap, gave little clue to diagnosis. Bone marrow biopsy showed 2~3 positive myelofibrosis. Test for BCR/ABL gene and JAK2/V617F mutation test were negative. Although marked eleveated CA19-9 and CA125 prompt the possibility of underlying malignancy, she refused to take any invasive diagnostic procedure for worrying about any adverse effect on her baby. The pregnancy was terminated in the 32nd week due to massive hematemesis. She gave birth a healthy boy. Bone marrow biopsy was repeated and malinant cells were detected. Immunohistological test showed the malignant cells expressing, suggestting their intestinal origin. The followed PET-CT scan detected an increased glucose-uptake mass at gastric angle, and also smaller sites on the ribs, vertebrates, pelvis and femurus. Biopsy of the gastric ulcer under gastroscope confirmed signet cell carcinoma. 3 weeks later, she ended up with massive gastric bleeding.

Signet cell carcinoma 
